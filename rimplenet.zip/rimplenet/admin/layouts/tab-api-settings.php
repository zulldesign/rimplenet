<div class="plugin-card-block">
					    <a href="javascript:void(0);" class="plugin-image">
							<img src="<?php echo plugin_dir_url(dirname( __FILE__ ));  ?>img/dot3-icon.png" alt="Demo Data">
						</a>
						<div class="plugin-card-top">
							<h3>API SETTINGS</h3>

							<div class="desc column-description">
							   <h3 style="color:red;">
							   <?php
							     echo __('API allows apps to talk to each other, once launched, you will be able to connect other apps to rimplenet','rimplenet');
							   ?>
							   </h3>
							 </div>

							<div class="action-links">
								<ul class="plugin-action-buttons">
									<li>
										<a href="javascript:void(0);" class="action-btn button">
										 <?php
            							     echo __('API Settings Coming Soon!!!','rimplenet');
            							  ?>
										</a>
									</li>
									<li>
										<a href="https://rimplenet.tawk.help" target="_blank">
											<?php
            							     //echo __('Learn More from Docs','rimplenet');
            							    ?>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
