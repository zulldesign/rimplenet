<div class="plugin-card-block">
					    <a href="javascript:void(0);" class="plugin-image">
							<img src="<?php echo plugin_dir_url(dirname( __FILE__ ));  ?>img/dot3-icon.png" alt="Demo Data">
						</a>
						<div class="plugin-card-top">
							<h3>DEMO DATA SETUP</h3>

							<div class="desc column-description">
							   <h3 style="color:red;">
							   <?php
							     echo __('That one page you can import rimplenet demo data and test how its functionalities works is COMING SOON & WILL BE RIGHT HERE','rimplenet');
							   ?>
							   </h3>
							 </div>

							<div class="action-links">
								<ul class="plugin-action-buttons">
									<li>
										<a href="javascript:void(0);" class="action-btn button">
										 <?php
            							     echo __('Import Demo Data Coming Soon!!!','rimplenet');
            							  ?>
										</a>
									</li>
									<li>
										<a href="https://rimplenet.com/docs/demo-data" target="_blank">
											<?php
            							     //echo __('Learn More from Docs','rimplenet');
            							    ?>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
